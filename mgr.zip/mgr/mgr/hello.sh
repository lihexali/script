#!/bin/bash

source ~/.bashrc
echo_hello
