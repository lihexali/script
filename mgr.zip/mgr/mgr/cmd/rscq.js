/**
 * Created by lihex on 5/6/17.
 * 修改成测试配置+重启
 */
var processUtils = require("../processUtils.js");
var path = require('path');
exports.exec = function(config, env, cb){
    processUtils.exec(config.shell_dir,
            "./rscq.sh",
            function(err, stdout, stderr){
        if(err){
            cb(stderr);
        }else{
            cb(null, stdout);
        }
    });
};
