/**
 * Created by lihex on 5/6/17.
 * 重启整个测试环境：一般有新表添加时需要调用此命令
 */
var processUtils = require("../processUtils.js");
var path = require('path');
exports.exec = function(config, env, cb){
    processUtils.exec(path.join(config.mgr_dir, '.'),
            "./hello.sh",
            function(err, stdout, stderr){
        if(err){
            cb(stderr);
        }else{
            cb(null, stdout);
        }
    });
};
