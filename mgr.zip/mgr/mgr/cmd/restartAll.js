/**
 * Created by lihex on 5/6/17.
 * 重启管理器 
 */
var processUtils = require("../processUtils.js");
var path = require('path');
exports.exec = function(config, env, cb){
    processUtils.exec(path.join(config.mgr_dir, '..'), "./restart_all.sh", function(err, stdout, stderr){
        if(err){
            cb(stderr);
        }else{
            cb(null, stdout);
        }
    });
};
