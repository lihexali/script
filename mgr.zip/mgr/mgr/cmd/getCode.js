/**
 * Created by lihex on 5/6/17.
 * 从svn获取最新测试代码
 */
var processUtils = require("../processUtils.js");
var path = require('path');
exports.exec = function(config, env, cb){
    processUtils.exec(config.data_dir,
            "svn export -r HEAD --username WallE  --password xxxxxx svn://modo7game.imwork.net/cq_release/chuanqi_client.zip --non-interactive --no-auth-cache && svn export -r HEAD --username WallE  --password xxxxxx svn://modo7game.imwork.net/cq_release/chuanqi_server.zip --non-interactive --no-auth-cache",
            function(err, stdout, stderr){
        if(err){
            cb(stderr);
        }else{
            cb(null, stdout);
        }
    });
};
