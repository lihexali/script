/**
 * Created by lihex on 5/6/17.
 * 只重启
 */
var processUtils = require("../processUtils.js");
var path = require('path');
exports.exec = function(config, env, cb){
    processUtils.exec(config.shell_dir,
            "./rscqOnly.sh",
            function(err, stdout, stderr){
        if(err){
            cb(stderr);
        }else{
            cb(null, stdout);
        }
    });
};
