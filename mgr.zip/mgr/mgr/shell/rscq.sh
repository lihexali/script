#!/bin/bash
source ~/.bashrc
setTestCfg
rscq
