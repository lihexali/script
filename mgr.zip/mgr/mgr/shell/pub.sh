#!/bin/bash
source ~/.bashrc
mgr_dir=/home/cq_tools/mgr
data_dir=$mgr_dir/mgr/data
cp -rf $data_dir/chuanqi_client.zip /tmp
cp -rf $data_dir/chuanqi_server.zip /tmp
pubcq
pubcqs
setTestCfg
rscq
