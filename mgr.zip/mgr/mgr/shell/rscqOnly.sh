#!/bin/bash
source ~/.bashrc
rscq
