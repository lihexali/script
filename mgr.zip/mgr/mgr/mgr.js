/**
 * Created by SmallAiTT on 2015/6/9.
 */
var http = require('http');
var url = require('url');
var fs = require('fs');
var path = require('path');
var cfg = {
    mgr_dir:__dirname
    ,shell_dir:path.join(__dirname, 'shell')
    ,data_dir:path.join(__dirname, 'data')
}
var env = {
    mgr:{
            host:"10.0.1.101",
            port:24109
        }
}
var processUtils = require('./processUtils.js');
var async = require('async');

function killByPorts(cb){
    var ports = [];
    async.map(ports, function(port, cb1){
        processUtils.killByPort(port, cb1);
    }, function(err){
        if(err) return console.error('kill ports-->', err);
        cb();
    });
}


// 服务器相关设置
var mine = {
    "css": "text/css",
    "gif": "image/gif",
    "html": "text/html",
    "ico": "image/x-icon",
    "jpeg": "image/jpeg",
    "jpg": "image/jpeg",
    "js": "text/javascript",
    "json": "application/json",
    "pdf": "application/pdf",
    "png": "image/png",
    "svg": "image/svg+xml",
    "swf": "application/x-shockwave-flash",
    "tiff": "image/tiff",
    "txt": "text/plain",
    "wav": "audio/x-wav",
    "wma": "audio/x-ms-wma",
    "mp3": "audio/mpeg",
    "wmv": "video/x-ms-wmv",
    "xml": "text/xml"
};
function onGet(request, response) {
    var pathname = url.parse(request.url).pathname;
    var arr = pathname.split("/");
    if(arr[1] == "cmd"){
        response.writeHead(200, { 'Content-Type': 'text/html;charset=utf-8' });
        var cmdName = arr[2];
        var cmdPath = path.join(__dirname, "./cmd", cmdName + ".js");
        console.log(cmdPath);
        if(!fs.existsSync(cmdPath)){
            return response.end("找不到cmd：【" + cmdName + "】！");
        }
        try{
            var cmd = require("./cmd/" + cmdName);
            cmd.exec(cfg, env, function(err, msg){
                if(err){
                    response.end(err);
                }else{
                    response.end("成功！\r\n" + msg);
                }
            });
        }catch(e){
            response.end("cmd：【" + cmdName + "】出错！\r\n" + e);
        }
    }else{
        writeFile(pathname, response);
    }
}


function writeFile(pathname, response) {
    var realPath = path.join(cfg.mgr_dir, pathname);
    var ext = path.extname(realPath);
    ext = ext ? ext.slice(1) : 'unknown';
    fs.exists(realPath, function (exists) {
        if (!exists) {
            response.writeHead(404, {
                'Content-Type': 'text/plain'
            });
            console.log(realPath);
            response.write("This request URL " + pathname + " was not found on this server.");
            response.end();
        } else {
            fs.readFile(realPath, "binary", function (err, file) {
                if (err) {
                    response.writeHead(500, {
                        'Content-Type': 'text/plain'
                    });
                    response.end(err.toString());
                } else {
                    var contentType = mine[ext] || "text/plain";
                    response.writeHead(200, {
                        'Accept-Ranges': 'bytes',
                        'Content-Type': contentType,
                        'Content-Length': file.length,
                        'Access-Control-Allow-Origin': '*'
                    });
                    response.write(file, "binary");
                    response.end();
                }
            });
        }
    });
}

var server = http.createServer(onGet);
server.addListener("error", function (err) {
    console.log("server error--->", err);
});

killByPorts(function(){
    server.listen(env.mgr.port, env.mgr.host, function(err){
        console.log("http server %s:%s", env.mgr.host, env.mgr.port);
    });
});
