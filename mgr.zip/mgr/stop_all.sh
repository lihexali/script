#!/bin/bash

DIR="$( cd "$( dirname "$0"  )" && pwd  )"
runpath=$DIR
logpath='/home/log/chuanqi/'
nodepath='$(which node)'

mgr_port=24109

cd $runpath

## stop mgr ##
stop_mgr() {
    echo "stoping mgr..."
    processid=`netstat -nvltp |grep node | grep -E "$mgr_port" |awk '{print $NF}' |awk -F"/" '{print $1}'`
    for id in $processid
    do
        kill $id
    done

    sleep 2
}

stop_mgr
