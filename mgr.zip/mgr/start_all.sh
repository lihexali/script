#!/bin/bash

DIR="$( cd "$( dirname "$0"  )" && pwd  )"
runpath=$DIR
logpath='/opt/log/cq_mgr'
nodepath=$(which node)

mkdir -p $logpath
cd $runpath

## start mgr  ##
start_mgr() {
    echo "Starting mgr..."
    nohup $nodepath ./mgr/mgr.js > "$logpath"/mgr.log 2>&1 &
    sleep 2
}

start_mgr


