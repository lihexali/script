#!/bin/bash
./stop_all.sh && ./start_all.sh
